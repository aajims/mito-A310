-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 13, 2017 at 11:15 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arif`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(4) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `email` varchar(45) NOT NULL,
  `level` varchar(15) NOT NULL,
  `id_bagian` int(3) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `nama_lengkap`, `no_telp`, `email`, `level`, `id_bagian`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Arif Sarifudin', '08787777771', 'admin@gmail.com', 'Admin', 3),
(2, 'ahmad', '61243c7b9a4022cb3f8dc3106767ed12', 'Ahmad setiawan', '087877777712', 'ahmad@gmail.com', 'supervisor', 2);

-- --------------------------------------------------------

--
-- Table structure for table `bagian`
--

CREATE TABLE IF NOT EXISTS `bagian` (
  `id_bagian` int(3) NOT NULL,
  `nm_bagian` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bagian`
--

INSERT INTO `bagian` (`id_bagian`, `nm_bagian`) VALUES
(1, 'Produksi'),
(2, 'PPIC'),
(3, 'HRD');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `id_karyawan` int(5) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nm_karyawan` varchar(55) NOT NULL,
  `jabatan` varchar(17) NOT NULL,
  `kelamin` varchar(10) NOT NULL,
  `no_telp` varchar(12) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `id_bagian` int(3) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nik`, `nm_karyawan`, `jabatan`, `kelamin`, `no_telp`, `tgl_masuk`, `id_bagian`) VALUES
(1, '2009802001', 'Ahmad Shaleh', 'Staff', 'Laki-laki', '08787777111', '2017-09-05', 1),
(2, '2009802001', 'Siti Khodijah', 'Staff', 'Perempuan', '087877771111', '2017-11-01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE IF NOT EXISTS `kriteria` (
  `id_kriteria` int(3) NOT NULL,
  `nm_kriteria` varchar(90) NOT NULL,
  `ket` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id_kriteria`, `nm_kriteria`, `ket`) VALUES
(1, 'Penguasaan Pekerjaan /Skill', '-'),
(2, 'Kejujuran /Dapat di percaya', ''),
(3, 'Tanggung jawab', '-'),
(4, 'Inisiatif /Bekerja tanpa harus di perintah', '-');

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE IF NOT EXISTS `nilai` (
  `id_nilai` int(3) NOT NULL,
  `id_karyawan` int(3) NOT NULL,
  `id_bagian` int(3) NOT NULL,
  `periode` varchar(9) NOT NULL,
  `id_admin` int(3) NOT NULL,
  `sts` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`id_nilai`, `id_karyawan`, `id_bagian`, `periode`, `id_admin`, `sts`) VALUES
(1, 1, 1, '2017-12', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_detail`
--

CREATE TABLE IF NOT EXISTS `nilai_detail` (
  `id_detail` int(3) NOT NULL,
  `id_karyawan` int(3) NOT NULL,
  `periode` varchar(9) NOT NULL,
  `id_kriteria` int(3) NOT NULL,
  `nilai` int(3) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai_detail`
--

INSERT INTO `nilai_detail` (`id_detail`, `id_karyawan`, `periode`, `id_kriteria`, `nilai`) VALUES
(1, 1, '2017-12', 2, 40),
(2, 1, '2017-12', 1, 20),
(3, 1, '2017-12', 3, 60),
(4, 1, '2017-12', 4, 80);

-- --------------------------------------------------------

--
-- Table structure for table `temp_nilai`
--

CREATE TABLE IF NOT EXISTS `temp_nilai` (
  `id_temp` int(5) NOT NULL,
  `id_kriteria` int(3) NOT NULL,
  `nilai` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `bagian`
--
ALTER TABLE `bagian`
  ADD PRIMARY KEY (`id_bagian`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `nilai_detail`
--
ALTER TABLE `nilai_detail`
  ADD PRIMARY KEY (`id_detail`);

--
-- Indexes for table `temp_nilai`
--
ALTER TABLE `temp_nilai`
  ADD PRIMARY KEY (`id_temp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `bagian`
--
ALTER TABLE `bagian`
  MODIFY `id_bagian` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id_karyawan` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id_kriteria` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id_nilai` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `nilai_detail`
--
ALTER TABLE `nilai_detail`
  MODIFY `id_detail` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `temp_nilai`
--
ALTER TABLE `temp_nilai`
  MODIFY `id_temp` int(5) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
