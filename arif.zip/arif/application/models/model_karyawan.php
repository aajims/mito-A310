<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_karyawan extends CI_Model {

	var $table = 'karyawan';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	function tampil_karyawan()
	{
		return $this->db->get($this->table);
	}
			
    function tampilkan(){
       //$this->db->from($this->table);
       $this->db->SELECT('karyawan.id_karyawan,karyawan.nm_karyawan,karyawan.jabatan,karyawan.tgl_masuk,karyawan.kelamin,bagian.nm_bagian');
       $this->db->join('bagian','karyawan.id_bagian=bagian.id_bagian');
       $query=$this->db->get($this->table);
       return $query->result();
    }

    function get_id($id){
		$this->db->SELECT('karyawan.id_karyawan,karyawan.nik,karyawan.no_telp,karyawan.id_bagian,karyawan.nm_karyawan,karyawan.jabatan,karyawan.tgl_masuk,karyawan.kelamin,bagian.nm_bagian');
		$this->db->join('bagian','karyawan.id_bagian=bagian.id_bagian');
		$this->db->where('id_karyawan',$id);
		$query = $this->db->get($this->table);
		return $query->row();
	}

    function tambah($data){
        $this->db->insert($this->table, $data);
		return $this->db->insert_id();
    }
    
    function update($where, $data){
       $this->db->update($this->table, $data, $where);
	return $this->db->affected_rows();
    }

    public function delete($id)	{
	$this->db->where('id_karyawan', $id);
	$this->db->delete($this->table);
	}

	function lap_kar($from,$to){
		$this->db->SELECT('karyawan.id_karyawan,karyawan.nm_karyawan,karyawan.jabatan,karyawan.tgl_masuk,karyawan.kelamin,bagian.nm_bagian');
		$this->db->WHERE('tgl_masuk BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"');
		$this->db->join('bagian','karyawan.id_bagian=bagian.id_bagian');
		return $this->db->get($this->table);
	}

	function pdf_kar($from,$to){
		$this->db->SELECT('karyawan.id_karyawan,karyawan.nm_karyawan,karyawan.jabatan,karyawan.tgl_masuk,karyawan.kelamin,bagian.nm_bagian');
		$this->db->WHERE('tgl_masuk BETWEEN "'. date('Y-m-d', strtotime($from)). '" and "'. date('Y-m-d', strtotime($to)).'"');
		$this->db->join('bagian','karyawan.id_bagian=bagian.id_bagian');
		return $this->db->get($this->table);
	}
}
