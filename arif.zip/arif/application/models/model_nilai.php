<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_nilai extends CI_Model {

	var $table = 'nilai';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	function tampil_nilai()
	{
		return $this->db->get($this->table);
	}
			
    function tampilkan(){
		$this->db->SELECT('nilai.id_nilai,nilai.periode,nilai.id_karyawan,bagian.nm_bagian,karyawan.nm_karyawan, admin.nama_lengkap');
		$this->db->join('bagian','nilai.id_bagian=bagian.id_bagian');
		$this->db->join('karyawan','nilai.id_karyawan=karyawan.id_karyawan');
		$this->db->join('admin','nilai.id_admin=admin.id_admin');
		$query=$this->db->get($this->table);
		return $query->result();
    }

	function tampilkeun($user){
		$this->db->SELECT('nilai.id_nilai,nilai.periode,bagian.nm_bagian,karyawan.nm_karyawan, admin.nama_lengkap');
		$this->db->WHERE('nilai.id_bagian', $user);
		$this->db->join('bagian','nilai.id_bagian=bagian.id_bagian');
		$this->db->join('karyawan','nilai.id_karyawan=karyawan.id_karyawan');
		$this->db->join('admin','nilai.id_admin=admin.id_admin');
		$query=$this->db->get($this->table);
		return $query->result();
	}

    function get_id($id){
		$this->db->from($this->table);
		$this->db->where('id_nilai',$id);
		$query = $this->db->get();
		return $query->row();
	}

	function simpanTmp($data){
		if ($this->db->select('id_temp')->where('id_kriteria', $data['id_kriteria'])->get('temp_nilai')->num_rows() > 0) {
			return $this->db->where('id_kriteria', $data['id_kriteria'])->update('temp_nilai', $data);
		} else {
			return $this->db->insert('temp_nilai', $data);
		}
	}

	function nilai(){
		$this->db->FROM('temp_nilai');
		//$this->db->WHERE('id_temp', $id);
		$query = $this->db->GET();
		return $query->result();
	}

	function tambah($data){
		$this->db->insert('nilai', $data);

		foreach ($this->db->get('temp_nilai')->result() as $val) {
			$datas['id_karyawan'] = $data['id_karyawan'];
			$datas['periode'] = $data['periode'];
			$datas['id_kriteria'] = $val->id_kriteria;
			$datas['nilai'] = $val->nilai;
			$this->db->insert('nilai_detail', $datas);
		}

		$this->db->truncate('temp_nilai');
	}

	function edit($user){
		$this->db->SELECT('nilai.id_nilai,nilai.id_karyawan,nilai.periode,bagian.nm_bagian,karyawan.nm_karyawan, admin.nama_lengkap');
		$this->db->WHERE('nilai.id_karyawan', $user);
		$this->db->FROM('nilai');
		$this->db->join('bagian','nilai.id_bagian=bagian.id_bagian');
		$this->db->join('karyawan','nilai.id_karyawan=karyawan.id_karyawan');
		$this->db->join('admin','nilai.id_admin=admin.id_admin');
		$query=$this->db->get();
		return $query->row();
	}

	function detail($id){
		$this->db->SELECT('nilai_detail.id_detail, nilai_detail.periode, nilai_detail.nilai, kriteria.nm_kriteria');
		$this->db->WHERE('nilai_detail.id_karyawan', $id);
		$this->db->from('nilai_detail');
		$this->db->JOIN('kriteria', 'nilai_detail.id_kriteria=kriteria.id_kriteria');
		$query = $this->db->get();
		return $query->result();
	}
    
    function update($where, $data){
       $this->db->update($this->table, $data, $where);
	return $this->db->affected_rows();
    }

    public function delete_id($id)	{
	$this->db->where('id_nilai', $id);
	$this->db->delete($this->table);
	}

}
