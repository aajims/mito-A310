<?php
Class Bagian extends CI_Controller{
       
         
    function __construct() {
        parent::__construct();
        $this->model_squrity->getsqurity();
        $this->load->database();
        $this->load->model('model_bagian');
        $this->load->library(array('template','pagination','form_validation'));
    }
        
    function index(){
        $data['judul']    = ' Halaman Data Bagian';
        $data['bagian']     = $this->model_bagian->tampilkan();
        $this->template->utama('master/view_bagian',$data);
       }

	/*function list_ajax()
	{

		$list = $this->model_bagian->tampilkan();
		$data = array();
		$no = 1;
		foreach ($list as $person) {

			$row = array();
			$row[] = $no;
			$row[] = $person->nm_bagian;

			//add html for action
			$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_person('."'".$person->id_bagian."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
				  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_person('."'".$person->id_bagian."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';

			$data[] = $row;
			$no++;
		}
		$output = array(
			//"draw" => $_POST['draw'],
			"data" => $data,
		);

		//output to json format
		echo json_encode($output);
	} */
       
       function tambah(){
    	$this->_validate();
        $data = array(
            'nm_bagian' => $this->input->post('nama'),

        );
        $this->model_bagian->tambah($data);
       echo json_encode(array("status" => TRUE));
    }
    
    function edit($id){
	$data = $this->model_bagian->get_id($id);
	echo json_encode($data);
		}
                
    function update(){
    	$this->_validate();
		$data = array(
			'nm_bagian' => $this->input->post('nama'),
		);
       $this->model_bagian->update(array('id_bagian' => $this->input->post('id_bagian')), $data);
		echo json_encode(array("status" => TRUE));
    }

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('nama') == '')
		{
			$data['inputerror'][] = 'nama';
			$data['error_string'][] = 'Nama Bagian Harus di Isi';
			$data['status'] = FALSE;
		}

		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
    
    function delete($id){
	$this->model_bagian->delete_id($id);
	echo json_encode(array("status" => TRUE));
    }
}
