<?php
Class Notif extends CI_Controller{
       
         
    function __construct() {
        parent::__construct();
        $this->model_squrity->getsqurity();
        $this->load->database();
        $this->load->model('model_notif');
    }
        
    function index(){
        $isi['jnotif']     = $this->model_notif->jum_notif();
		$isi['getnotif']     = $this->model_notif->get_notif();
        $this->load->view('template/topbar',$isi);
       }

	function load_row(){
		echo $this->model_notif->jum_notif();
	}

	function view(){
		echo $this->model_notif->count();
	}

	function load_data(){
		$data=$this->model_notif->get_notif();
		$no=0;foreach($data as $rdata){ $no++;
			if($no % 2==0){$strip='strip1';}
			else{$strip='strip2';}
			echo"<li><a href=\"#\" class=\"".$strip."\">".$rdata->id_bagian."  
            <small>".$rdata->nm_bagian." </small>
            </a><li>";
		}
	}
}
