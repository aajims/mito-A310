<?php
Class Profil extends CI_Controller{
       
         
    function __construct() {
        parent::__construct();
        $this->model_squrity->getsqurity();
        $this->load->database();
        $this->load->model('model_profil');
        $this->load->library(array('template','pagination','form_validation','upload'));
    }
        
    function index(){
    	$username= $this->session->userdata("username");
        $isi['judul']    = ' Halaman Profil';
        $isi['profil']     = $this->model_profil->tampilkan($username);
        $this->template->utama('master/view_profil',$isi);
        
       }
       
	   function edit($id){
		$data = $this->model_profil->get_id($id);
		echo json_encode($data);
		}
          
    function update(){
    		if ($this->input->post('pass')) {           
            $data=array(            	
                'username'=>$this->input->post('user'),
                'username' => $this->input->post('user'),
	            'password' => md5($this->input->post('pass')),
	            'nama_lengkap' => $this->input->post('nama'),
	            'no_telp' => $this->input->post('telp'),
	            'level' => $this->input->post('level'),
	            'id_bagian' => $this->input->post('bag'),
	            'email'=>  $this->input->post('email')                
            );
			} else {
				 $data=array(            	
                'username'=>$this->input->post('user'),
                'username' => $this->input->post('user'),	            
	            'nama_lengkap' => $this->input->post('nama'),
	            'no_telp' => $this->input->post('telp'),
				 'level' => $this->input->post('level'),
				 'id_bagian' => $this->input->post('bag'),
	            'email'=>  $this->input->post('email')
			);	
		}
            $this->model_profil->update(array('id_admin' => $this->input->post('id_admin')), $data);
			echo json_encode(array("status" => TRUE));       
		}
                
    function updatee(){
         $data = array(
            'id_admin' => $this->input->post('id_admin'),
            'username' => $this->input->post('user'),
            'password' => md5($this->input->post('pass')),
            'nama_lengkap' => $this->input->post('nama'),
            'no_telp' => $this->input->post('telp'),
            'email'=>  $this->input->post('email')
        );
       $this->model_admin->update(array('id_admin' => $this->input->post('id_admin')), $data);
	echo json_encode(array("status" => TRUE));
    }
    
    function delete($id){
	$this->model_admin->delete_id($id);
	echo json_encode(array("status" => TRUE));
    }
}
