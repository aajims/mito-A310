<?php
Class Kriteria extends CI_Controller{
       
         
    function __construct() {
        parent::__construct();
        $this->model_squrity->getsqurity();
        $this->load->database();
        $this->load->model('model_kriteria');
        $this->load->library(array('template','pagination','form_validation'));
    }
        
    function index(){
        $isi['judul']    = ' Halaman Data Kriteria';
        $isi['kriteria']     = $this->model_kriteria->tampilkan();
        $this->template->utama('transaksi/view_kriteria',$isi);
       }
	function addview(){
		$data['judul']    = 'Tambah Data Kriteria';
		$this->template->utama('transaksi/add_kriteria',$data);
	}
       
    function add(){
        $data = array(
            'nm_kriteria' => $this->input->post('nama'),
			'ket' => $this->input->post('ket')
        );
        $this->model_kriteria->tambah($data);
		$this->session->set_flashdata('success', 'Transaksi Berhasil di Simpan');
		redirect('kriteria');
    }

	function edit($id){
		$data['judul']    = ' Halaman Edit Kriteria';
		$data['row'] = $this->model_kriteria->get_id($id);
		$this->template->utama('transaksi/edit_kriteria',$data);
	}
                
    function update(){
		$data = array(
			'nm_kriteria' => $this->input->post('nama'),
			'ket' => $this->input->post('ket')
		);
       $this->model_kriteria->update(array('id_kriteria' => $this->input->post('id')), $data);
	   $this->session->set_flashdata('success', 'Transaksi Berhasil di Update');
	   redirect('kriteria');
    }
    
    function delete($id){
	$this->model_kriteria->delete_id($id);
	echo json_encode(array("status" => TRUE));
    }
}
