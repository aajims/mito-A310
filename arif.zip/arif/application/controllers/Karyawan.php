<?php
Class Karyawan extends CI_Controller{
       
         
    function __construct() {
        parent::__construct();
        $this->model_squrity->getsqurity();
        $this->load->database();
        $this->load->model(array('model_karyawan','model_notif'));
        $this->load->library(array('template','pagination','form_validation'));
    }
        
    function index(){
        $isi['judul']    = ' Halaman Data Karyawan';
		$isi['jnotif']		= $this->model_notif->jum_notif();
		$isi['getnotif']	= $this->model_notif->get_notif();
        $isi['karyawan']     = $this->model_karyawan->tampilkan();
        $this->template->utama('master/view_karyawan',$isi);
       }

	function addview(){
		$data['judul']    = 'Tambah Data Karyawan';
		$this->template->utama('master/add_karyawan',$data);
	}

	function add(){
		$data = array(
			'nik' => $this->input->post('nik'),
			'nm_karyawan' => $this->input->post('nama'),
			'jabatan' => $this->input->post('jab'),
			'kelamin' => $this->input->post('jk'),
			'no_telp' => $this->input->post('telp'),
			'tgl_masuk' => $this->input->post('tgl'),
			'id_bagian' => $this->input->post('bag')
		);
		$this->model_karyawan->tambah($data);
		$this->session->set_flashdata('success', 'Transaksi Berhasil di Simpan');
		redirect('karyawan');
	}
    
    function edit($id){
		$data['judul']    = ' Halaman Edit Karyawan';
		$data['row'] = $this->model_karyawan->get_id($id);
		$this->template->utama('master/edit_karyawan',$data);
	}
                
    function update(){
		$data = array(
			'nik' => $this->input->post('nik'),
			'nm_karyawan' => $this->input->post('nama'),
			'jabatan' => $this->input->post('jab'),
			'kelamin' => $this->input->post('jk'),
			'no_telp' => $this->input->post('telp'),
			'tgl_masuk' => $this->input->post('tgl'),
			'id_bagian' => $this->input->post('bag')
		);
       $this->model_karyawan->update(array('id_karyawan' => $this->input->post('id')), $data);
		$this->session->set_flashdata('success', 'Transaksi Berhasil di Update');
		redirect('Karyawan');
    }

	function delete($id){
		$this->model_karyawan->delete_id($id);
		redirect('karyawan');
	}

	function lap(){
		$data['judul']    = 'Laporan Karyawan';
		$this->template->utama('laporan/lap_karyawan',$data);
	}

	function aksi_lap($from, $to){
		$dt['kar'] 	= $this->model_karyawan->lap_kar($from, $to);
		$dt['from']			= date('d F Y', strtotime($from));
		$dt['to']			= date('d F Y', strtotime($to));
		$this->load->view('laporan/laporan_karyawan', $dt);
	}

	function laporan_pdf($from,$to){
		$this->load->library('cfpdf');
		$tgl = date('d F Y');
		$nama = $this->session->userdata('nama_lengkap');

		$pdf = new FPDF('P','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',17);

		$pdf->Cell(0, 10, "Laporan Karyawan ", 20, 1, 'C');
		$pdf->Cell(0, 10, "Periode ".date('d/m/Y', strtotime($from))." - ".date('d/m/Y', strtotime($to)), 0, 1, 'C');
		$pdf->Ln(10);
		$pdf->SetFont('Arial','',10);

		$pdf->Cell(7, 7, 'No', 1, 0, 'L');
		$pdf->Cell(40, 7, 'Nama Karyawan', 1, 0, 'L');
		$pdf->Cell(35, 7, 'Jabatan', 1, 0, 'L');
		$pdf->Cell(25, 7, 'Jenis Kelamin', 1, 0, 'L');
		$pdf->Cell(25, 7, 'Tgl Masuk', 1, 0, 'L');
		$pdf->Cell(30, 7, 'Bagian', 1, 0, 'L');
		$pdf->Ln();

		$transaksi 	= $this->model_karyawan->pdf_kar($from, $to);

		$no = 1;

		foreach($transaksi->result() as $p)
		{
			$pdf->Cell(7, 7, $no, 1, 0, 'L');
			$pdf->Cell(40, 7, $p->nm_karyawan, 1, 0, 'L');
			$pdf->Cell(35, 7, $p->jabatan, 1, 0, 'L');
			$pdf->Cell(25, 7, $p->kelamin, 1, 0, 'L');
			$pdf->Cell(25, 7, date('d/m/Y', strtotime($p->tgl_masuk)), 1, 0, 'L');
			$pdf->Cell(30, 7, $p->nm_bagian, 1, 0, 'L');
			$pdf->Ln();

			$no++;
		}

		$pdf->Ln();
		$pdf->Cell(0, 1, "Mengetahui,  ", 20, 1, 'R');

		$pdf->Cell(0, 2, "Tangerang,  ".date('d/m/Y', strtotime($tgl)), 0, 1, 'L');
		$pdf->Ln(19);
		$pdf->Cell(0, 1, " Manager ", 0, 1, 'R');
		$pdf->Cell(0, 1, "$nama ", 0, 1, 'L');

		$pdf->Output();
	}

}
