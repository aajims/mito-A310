<?php
Class Nilai extends CI_Controller{
       
         
    function __construct() {
        parent::__construct();
        $this->model_squrity->getsqurity();
        $this->load->database();
        $this->load->model(array('model_nilai','model_kriteria'));
        $this->load->library(array('template','pagination','form_validation'));
    }
        
    function index(){
        $isi['judul']    = 'Data Nilai Karyawan';
        $isi['nilai']     = $this->model_nilai->tampilkan();
        $this->template->utama('transaksi/view_nilai',$isi);
       }
	function search(){
		$keyword = $this->uri->segment(3);
		$data = $this->db->from('karyawan')->like('nm_karyawan',$keyword)->get();
		foreach($data->result() as $row)
		{
			$arr['query'] = $keyword;
			$arr['suggestions'][] = array(
				'value'	=>$row->nm_karyawan,
				'nama'	=>$row->nm_karyawan,
				'id_kar' => $row->id_karyawan
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}

	function view(){
		$id = $this->session->userdata('bagian');
		$isi['judul']    = 'Data Nilai Karyawan';
		$isi['nilai']     = $this->model_nilai->tampilkeun($id);
		$this->template->utama('transaksi/vieww_nilai',$isi);
	}

	function addview(){
		$data['judul']    = 'Tambah Data Kriteria';
		$data['nilai']	  = $this->model_kriteria->tampil_nilai();
		$data['rating']	= $this->model_nilai->nilai();
		$data['kriteria'] = $this->model_kriteria->tampilkan();
		$this->template->utama('transaksi/add_nilai',$data);
	}

	function tambah(){
		$data=array(
			'id_kriteria' => $this->input->post('id_kriteria'),
			'nilai' => $this->input->post('nilai')
		);
		$this->model_nilai->simpanTmp($data);
	}
       
    function add(){
        $data = array(
            'id_bagian' => $this->input->post('bag'),
			'id_karyawan' => $this->input->post('id_kar'),
			'periode' => $this->input->post('per'),
			'sts'	=> '1',
			'id_admin' => $this->session->userdata('admin')
        );
        $this->model_nilai->tambah($data);
		$this->session->set_flashdata('success', 'Transaksi Berhasil di Simpan');
		redirect('nilai');
    }

	function lihat($id){
		$data['judul']    = 'View Data Nilai';
		$data['nilai']	  = $this->model_nilai->edit($id);
		$data['detail']	  = $this->model_nilai->detail($id);
		$this->template->utama('transaksi/v_nilai',$data);
	}

	function edit($id){
		$data['judul']    = ' Halaman Edit Kriteria';
		$data['row'] = $this->model_nilai->get_id($id);
		$this->template->utama('transaksi/edit_nilai',$data);
	}
                
    function update(){
		$data = array(
			'nm_nilai' => $this->input->post('nama'),
			'ket' => $this->input->post('ket')
		);
       $this->model_nilai->update(array('id_nilai' => $this->input->post('id')), $data);
	   $this->session->set_flashdata('success', 'Transaksi Berhasil di Update');
	   redirect('nilai');
    }
    
    function delete($id){
	$this->model_nilai->delete_id($id);
	echo json_encode(array("status" => TRUE));
    }

	function lap(){
		$data['judul']    = 'Laporan Nilai Karyawan';
		$this->template->utama('laporan/lap_nilai',$data);
	}

	function aksi_lap($from, $to){
		$dt['nilai'] 	= $this->model_nilai->lap_nilai($from, $to);
		$dt['from']			= date('d F Y', strtotime($from));
		$dt['to']			= date('d F Y', strtotime($to));
		$this->load->view('laporan/laporan_nilai', $dt);
	}

	function laporan_pdf($from,$to){
		$this->load->library('cfpdf');
		$tgl = date('d F Y');
		$nama = $this->session->userdata('nama_lengkap');

		$pdf = new FPDF('P','mm','A4');
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',17);

		$pdf->Cell(0, 10, "Laporan Nilai Karyawan ", 20, 1, 'C');
		$pdf->Cell(0, 10, "Periode ".date('d/m/Y', strtotime($from))." - ".date('d/m/Y', strtotime($to)), 0, 1, 'C');
		$pdf->Ln(10);
		$pdf->SetFont('Arial','',10);

		$pdf->Cell(7, 7, 'No', 1, 0, 'L');
		$pdf->Cell(40, 7, 'Nama Karyawan', 1, 0, 'L');
		$pdf->Cell(35, 7, 'Bagian', 1, 0, 'L');
		$pdf->Cell(25, 7, 'Nama atasan', 1, 0, 'L');
		$pdf->Cell(25, 7, 'Kriteria', 1, 0, 'L');
		$pdf->Cell(30, 7, 'Nilai', 1, 0, 'L');
		$pdf->Ln();

		$transaksi 	= $this->model_nilai->pdf_kar($from, $to);

		$no = 1;

		foreach($transaksi->result() as $p)
		{
			$pdf->Cell(7, 7, $no, 1, 0, 'L');
			$pdf->Cell(40, 7, $p->nm_karyawan, 1, 0, 'L');
			$pdf->Cell(35, 7, $p->nm_bagian, 1, 0, 'L');
			$pdf->Cell(25, 7, $p->nama_lengkap, 1, 0, 'L');
			$pdf->Cell(25, 7, $p->nm_kriteria, 1, 0, 'L');
			$pdf->Cell(30, 7, $p->nilai, 1, 0, 'L');
			$pdf->Ln();

			$no++;
		}

		$pdf->Ln();
		$pdf->Cell(0, 1, "Mengetahui,  ", 20, 1, 'R');

		$pdf->Cell(0, 2, "Tangerang,  ".date('d/m/Y', strtotime($tgl)), 0, 1, 'L');
		$pdf->Ln(19);
		$pdf->Cell(0, 1, " Manager ", 0, 1, 'R');
		$pdf->Cell(0, 1, "$nama ", 0, 1, 'L');

		$pdf->Output();
	}
}
