<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    
     function __construct() {
        parent::__construct();
        $this->model_squrity->getsqurity();
		$this->load->model(array('model_admin','model_karyawan','model_notif', 'model_nilai','model_bagian'));
        $this->load->helper(array('form', 'url', 'fungsi'));
        $this->load->library(array('template','pagination','form_validation'));
        
    }

	public function index(){
        $data['judul']    	= 'Halaman Dashboard';
		$data['karyawan']	= $this->model_karyawan->tampil_karyawan()->num_rows();
		$data['admin']		= $this->model_admin->tampil_admin()->num_rows();
		$data['nilai']		= $this->model_nilai->tampil_nilai()->num_rows();
		$data['bagian']		= $this->model_bagian->tampil_bagian()->num_rows();
		$this->template->utama('dashboard', $data);
		
	}



}
