<div class="row">
	<!-- Welcome -->
	<div class="col-lg-12">
		<div class="alert alert-info">
			<i class="fa fa-folder-open"></i><b>&nbsp;Hello ! </b>Welcome Back <b><?php echo $this->session->userdata("nama_lengkap"); ?> </b>
		</div>
	</div>
	<!--end  Welcome -->
</div>
<div class="row">
	<!--quick info section -->
	<div class="col-lg-3">
		<div class="panel panel-primary text-center no-boder">
			<div class="panel-body yellow">
				<i class="fa fa-user fa-3x"></i>
				<h3><?php echo $admin; ?> </h3>
			</div>
			<div class="panel-footer">
				<span class="panel-eyecandy-title">Data User
				</span>
			</div>
		</div>
	</div>
	<div class="col-lg-3">
		<div class="panel panel-primary text-center no-boder">
			<div class="panel-body blue">
				<i class="fa fa-users fa-3x"></i>
				<h3><?php echo $karyawan; ?> </h3>
			</div>
			<div class="panel-footer">
				<span class="panel-eyecandy-title">Data Karyawan
				</span>
			</div>
		</div>
	</div>
	<div class="col-lg-3">
		<div class="panel panel-primary text-center no-boder">
			<div class="panel-body green">
				<i class="fa fa fa-star fa-3x"></i>
				<h3><?=$nilai; ?></h3>
			</div>
			<div class="panel-footer">
				<span class="panel-eyecandy-title">Data Nilai
				</span>
			</div>
		</div>
	</div>
	<div class="col-lg-3">
		<div class="panel panel-primary text-center no-boder">
			<div class="panel-body red">
				<i class="fa fa-indent fa-3x"></i>
				<h3><?=$bagian; ?></h3>
			</div>
			<div class="panel-footer">
				<span class="panel-eyecandy-title">Data Bagian
				</span>
			</div>
		</div>
	</div>
	<!--end quick info section -->
</div>

<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="panel panel-success">
			<div class="panel-heading">
				<h3>Selamat datang <br> di Aplikasi Penilaian Kinerja Karyawan</h3>
			</div>
			<div class="panel-body">
				<p>Aplikasi Penilaian Karyawan pada PT Arai Rubber Seal Indonesia ini di buat untuk memenuhi akan data kinerja karyawan yang cepat akurat dan efesien Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt est vitae ultrices accumsan. Aliquam ornare lacus adipiscing, posuere lectus et, fringilla augue.</p>
			</div>
			<div class="panel-footer">
				Panel Footer
			</div>
		</div>
	</div>

</div>
