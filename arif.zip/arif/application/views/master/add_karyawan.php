	<div class="panel panel-default">
	  <div class="panel-body">
		<div class="row">
			<div class="col-lg-12">
				<!-- Advanced Tables -->
				<div class="col-md-6 col-sm-6">
					<form method="post" action="<?php echo site_url()?>karyawan/add" enctype="multipart/form-data" >
						<div class="form-group">
							<label>Nik Karyawan</label>
							<input type="text" class="form-control" name="nik" placeholder="Input Nik Karyawan" data-validation="required" autofocus>
						</div>
						<div class="form-group">
							<label>Nama Karyawan</label>
							<input type="text" class="form-control" name="nama" placeholder="Input Nama Karyawan" data-validation="required">
						</div>
						<div class="form-group">
							<label>jabatan</label>
							<select class="form-control" name="jab" data-validation="required">
								<option value="">-- Pilih Jabatan --</option>
								<option value="Supervisor">Supervisor</option>
								<option value="Staff">Staff</option>
								<option value="Operator">Operator</option>
							</select>
						</div>
						<div class="form-group">
							<label>Jenis Kelamin</label><br>
							<div class="segmented-control" style="width: 50%; color: #5FBAAC">
								<input type="radio" name="jk" value="Laki-laki" id="laki" checked="">
								<input type="radio" name="jk" value="Perempuan" id="per">
								<label for="laki" data-value="Laki-laki">Laki-laki</label>
								<label for="per" data-value="Perempuan">Perempuan</label>
							</div>
						</div>
						<div class="form-group">
							<label>No telp</label>
							<input type="number" class="form-control" name="telp" placeholder="Input No Telp max 12 Digit" data-validation="required" data-validation="length" data-validation-length="max12">
						</div>
						<div class="form-group">
							<label>Tanggal Masuk</label>
							<div class="input-group date">
							<div class="input-group-addon">
								<i class="fa fa-calendar"></i>
							</div>
							<input type="text" class="form-control" name="tgl" id="tgl" >
							</div>
						</div>
						<div class="form-group">
							<label>Bagian</label>
							<select class="form-control" name="bag" data-validation="required">
								<option value="">-- Pilih Bagian --</option>
								<?php $jenis = $this->db->get('bagian');
								foreach ($jenis->result()as $row){
									?>
									<option class="form-control" value="<?php echo $row->id_bagian ?>"><?php echo $row->nm_bagian; ?></option>
								<?php } ?>
							</select>
						</div>
						<button class="btn btn-primary">Simpan</button>
						<a href="<?php echo site_url() ?>karyawan" class="btn btn-danger">Kembali</a>
					</form>
				</div>
			</div>
		</div>
	  </div>
	</div>
	<script>
		var myLanguage = {
			errorTitle : 'Tidak dapat dilanjutkan!',
			requiredFields : 'inputan ini harus diisi',
			badTime : 'Harus format waktu',
			badEmail : 'Harus format email',
			badTelephone : 'Harus format telepon',
			badSecurityAnswer : 'Pertanyaan keamanan salah',
			badDate : 'Kesalahan menulis tanggal',
			lengthBadStart : 'Harus input karakter antara ',
			lengthBadEnd : ' Karakter',
			lengthTooLongStart : 'Panjang karakter harus Kurang dari ',
			lengthTooShortStart : 'Panjang karakter harus Minimal ',
			notConfirmed : 'Konfirmasi terlebih dahulu',
			badDomain : 'Harus format nama domain',
			badUrl : 'Harus format URL',
			badCustomVal : 'You gave an incorrect answer',
			badInt : 'Harus karakter angka',
			badSecurityNumber : 'Your social security number was incorrect',
			badUKVatAnswer : 'Incorrect UK VAT Number',
			badStrength : 'The password isn\'t strong enough',
			badNumberOfSelectedOptionsStart : 'You have to choose at least ',
			badNumberOfSelectedOptionsEnd : ' answers',
			badAlphaNumeric : 'The answer you gave must contain only alphanumeric characters ',
			badAlphaNumericExtra: ' and ',
			wrongFileSize : 'The file you are trying to upload is too large',
			wrongFileType : 'The file you are trying to upload is of wrong type',
			groupCheckedRangeStart : 'Please choose between ',
			groupCheckedTooFewStart : 'Please choose at least ',
			groupCheckedTooManyStart : 'Please choose a maximum of ',
			groupCheckedEnd : ' item(s)'
		};
		$.validate({
			language : myLanguage
		});
	</script>
