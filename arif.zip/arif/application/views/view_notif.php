<?php
$response='';
while($row=mysqli_fetch_array($result)) {
	$response = $response . "<div class='notification-item'>" .
		"<div class='notification-subject'>". $row["subject"] . "</div>" .
		"<div class='notification-comment'>" . $row["comment"]  . "</div>" .
		"</div>";
}
if(!empty($response)) {
	print $response;
}
