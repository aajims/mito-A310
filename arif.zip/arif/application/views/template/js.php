<script src="<?php echo base_url(); ?>siminta/assets/scripts/jquery-3.0.0.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/plugins/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/plugins/pace/pace.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/plugins/bootstrap/siminta.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/scripts/jquery.form-validator.min.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/scripts/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/plugins/bootstrap/star-rating.js"></script>
<script src="<?php echo base_url(); ?>siminta/rating-master/dist/jquery.barrating.min.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/scripts/jquery.autocomplete.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/scripts/jquery.validate.min.js"></script>

<!-- Page-Level Plugin Scripts-->
<script src="<?php echo base_url(); ?>siminta/assets/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>siminta/assets/plugins/dataTables/dataTables.bootstrap.js"></script>
