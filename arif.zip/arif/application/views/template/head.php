
<!-- Core CSS - Include with every page -->
<link rel="shortcut icon" href="<?php echo base_url() ?>siminta/assets/img/arai.png">
<link href="<?php echo base_url(); ?>siminta/assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/plugins/bootstrap/star-rating.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/css/style.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/css/main-style.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/css/segmented-controls.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/css/datepicker3.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/assets/plugins/fonts/glyphicons.min.css" rel="stylesheet" />
<link href="<?php echo base_url(); ?>siminta/rating-master/dist/themes/fontawesome-stars.css" rel="stylesheet" />
<!-- Page-Level CSS -->
<link href="<?php echo base_url(); ?>siminta/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

