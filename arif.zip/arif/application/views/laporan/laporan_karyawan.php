<?php if($kar->num_rows() > 0) { ?>

	<table class='table table-bordered'>
		<thead>
			<tr>
			 <th>No</th>
				<th>Nama Karyawan</th>
				<th>Jabatan</th>
				<th>Jenis Kelamin</th>
				<th>Tgl Masuk</th>
				<th>Bagian</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$no = 1;
			foreach($kar->result() as $row)
			{
				echo "
					<tr>
						<td>".$no."</td>
						<td>".$row->nm_karyawan."</td>
						<td>".$row->jabatan."</td>
						<td>".$row->kelamin."</td>
						<td>".$row->tgl_masuk."</td>
						<td>".$row->nm_bagian."</td>				
					</tr>
				";
				$no++;
			}
			?>
		</tbody>
	</table>

	<p>
		<?php
		$from 	= date('Y-m-d', strtotime($from));
		$to		= date('Y-m-d', strtotime($to));
		?>
		<a href="<?php echo site_url('karyawan/laporan_pdf/'.$from.'/'.$to); ?>" target='blank' class='btn btn-default'><img width="45" height="45" src="<?php echo base_url(); ?>siminta/assets/img/pdf.jpg"> Export ke PDF</a>
	</p>
	<br />
<?php } ?>

<?php if($kar->num_rows() == 0) { ?>
<div class='alert alert-info'>
Data dari tanggal <b><?php echo $from; ?></b> sampai tanggal <b><?php echo $to; ?></b> tidak ditemukan
</div>
<br />
<?php } ?>
