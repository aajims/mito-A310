<?php if($kar->num_rows() > 0) { ?>

	<table class='table table-bordered'>
		<thead>
			<tr>
			 <th>No</th>
				<th>Nama Karyawan</th>
				<th>Bagian</th>
				<th>Nama atasan</th>
				<th>Kriteria</th>
				<th>Nilai</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$no = 1;
			foreach($nilai->result() as $row)
			{
				echo "
					<tr>
						<td>".$no."</td>
						<td>".$row->nm_karyawan."</td>
						<td>".$row->nm_bagian."</td>
						<td>".$row->nama_lengkap."</td>
						<td>".$row->nm_kriteria."</td>
						<td>".$row->nilai."</td>				
					</tr>
				";
				$no++;
			}
			?>
		</tbody>
	</table>

	<p>
		<?php
		$from 	= date('Y-m-d', strtotime($from));
		$to		= date('Y-m-d', strtotime($to));
		?>
		<a href="<?php echo site_url('nilai/laporan_pdf/'.$from.'/'.$to); ?>" target='blank' class='btn btn-default'><img width="45" height="45" src="<?php echo base_url(); ?>siminta/assets/img/pdf.jpg"> Export ke PDF</a>
	</p>
	<br />
<?php } ?>

<?php if($kar->num_rows() == 0) { ?>
<div class='alert alert-info'>
Data dari tanggal <b><?php echo $from; ?></b> sampai tanggal <b><?php echo $to; ?></b> tidak ditemukan
</div>
<br />
<?php } ?>
