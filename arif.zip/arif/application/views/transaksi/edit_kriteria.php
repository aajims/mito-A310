	<div class="panel panel-default">
	  <div class="panel-body">
		<div class="row">
			<div class="col-lg-12">
				<!-- Advanced Tables -->
				<div class="col-md-6 col-sm-6">
					<form method="post" action="<?php echo site_url()?>kriteria/update" enctype="multipart/form-data" >
						<div class="form-group">
							<label>Kriteria</label>
							<input type="hidden" name="id" value="<?php echo $row->id_kriteria; ?>">
							<input type="text" class="form-control" name="nama" value="<?php echo $row->nm_kriteria; ?>"  data-validation="required" >
						</div>
						<div class="form-group">
							<label>Keterangan</label>
							<input type="text" name="ket" class="form-control" value="<?php echo $row->ket; ?>" >
						</div>
						<br>
						<button class="btn btn-primary">Update</button>
						<a href="<?php echo site_url() ?>kriteria" class="btn btn-danger">Kembali</a>
					</form>
				</div>
			</div>
		</div>
	  </div>
	</div>
	<script>
		var myLanguage = {
			errorTitle : 'Tidak dapat dilanjutkan!',
			requiredFields : 'inputan ini harus diisi',
			badTime : 'Harus format waktu',
			badEmail : 'Harus format email',
			badTelephone : 'Harus format telepon',
			badSecurityAnswer : 'Pertanyaan keamanan salah',
			badDate : 'Kesalahan menulis tanggal',
			lengthBadStart : 'Harus input karakter antara ',
			lengthBadEnd : ' Karakter',
			lengthTooLongStart : 'Panjang karakter harus Kurang dari ',
			lengthTooShortStart : 'Panjang karakter harus Minimal ',
			notConfirmed : 'Konfirmasi terlebih dahulu',
			badDomain : 'Harus format nama domain',
			badUrl : 'Harus format URL',
			badCustomVal : 'You gave an incorrect answer',
			badInt : 'Harus karakter angka',
			badSecurityNumber : 'Your social security number was incorrect',
			badUKVatAnswer : 'Incorrect UK VAT Number',
			badStrength : 'The password isn\'t strong enough',
			badNumberOfSelectedOptionsStart : 'You have to choose at least ',
			badNumberOfSelectedOptionsEnd : ' answers',
			badAlphaNumeric : 'The answer you gave must contain only alphanumeric characters ',
			badAlphaNumericExtra: ' and ',
			wrongFileSize : 'The file you are trying to upload is too large',
			wrongFileType : 'The file you are trying to upload is of wrong type',
			groupCheckedRangeStart : 'Please choose between ',
			groupCheckedTooFewStart : 'Please choose at least ',
			groupCheckedTooManyStart : 'Please choose a maximum of ',
			groupCheckedEnd : ' item(s)'
		};
		$.validate({
			language : myLanguage
		});
	</script>
