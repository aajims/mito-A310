<div class="row">
	<div class="col-lg-12">
		<!-- Advanced Tables -->
		<?php if ($this->session->flashdata('success')): ?>
			<div class="alert bg-success" role="alert">
				<span><?php echo $this->session->flashdata('success'); ?></span>
			</div>
		<?php endif; ?>
		<div style="margin-bottom: 20px">
		<a class="btn btn-success" href="<?php echo site_url() ?>kriteria/addview"><i class="glyphicon glyphicon-plus"></i> Add Kriteria</a>
		</div>
		<div class="panel panel-default">
			<div class="panel-heading">
				Data User
			</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover" id="dataTables-example">
						<thead>
						<tr>
							<th>No </th>
							<th>Nama Kriteria</th>
							<th>Keterangan</th>
							<th>Action</th>
						</tr>
						</thead>
						<tbody>
						<?php $no=1; foreach($kriteria as $row){ ?>
							<tr>
								<td><?php echo $no;?></td>
								<td><?php echo $row->nm_kriteria; ?></td>
								<td><?php echo $row->ket; ?></td>
								<td class="center">
									<a href="<?php echo site_url('kriteria/edit/'.$row->id_kriteria) ?>" class="btn btn-primary" >
										<i class="fa fa-pencil"></i>
									</a>
									<a class="btn btn-danger" onclick="return confirm('Anda Yakin akan Hapus Data Ini.....??')" href="<?php echo site_url('kriteria/delete/'.$row->id_kriteria); ?>">
										<i class="fa fa-trash-o"></i>
									</a>
								</td>
							</tr>
							<?php $no++; }?>
						</tbody>
					</table>
				</div>

			</div>
		</div>
		<!--End Advanced Tables -->
	</div>
</div>
