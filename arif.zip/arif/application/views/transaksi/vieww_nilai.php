<div class="row">
	<div class="col-lg-12">
		<!-- Advanced Tables -->
		<?php if ($this->session->flashdata('success')): ?>
			<div class="alert bg-success" role="alert">
				<span><?php echo $this->session->flashdata('success'); ?></span>
			</div>
		<?php endif; ?>
		<div style="margin-bottom: 20px">
		<a class="btn btn-success" href="<?php echo site_url() ?>nilai/addview"><i class="glyphicon glyphicon-plus"></i> Add Nilai</a>
		</div>
		<div class="panel panel-default">
			<div class="panel-heading">
				Data User
			</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover" id="dataTables-example">
						<thead>
						<tr>
							<th>No </th>
							<th>Nama Bagian</th>
							<th>Nama Karyawan</th>
							<th>Periode</th>
							<th>Atasan</th>
							<th>Action</th>
						</tr>
						</thead>
						<tbody>
						<?php $no=1; foreach($nilai as $row){ ?>
							<tr>
								<td><?php echo $no;?></td>
								<td><?php echo $row->nm_bagian; ?></td>
								<td><?php echo $row->nm_karyawan; ?></td>
								<td><?php echo $row->periode; ?></td>
								<td><?php echo $row->nama_lengkap; ?></td>
								<td class="center">
									<a class="btn btn-primary" href="<?php echo site_url('nilai/lihat/'.$row->id_nilai) ?>"><i class="fa fa-search"></i> </a>
									<a class="btn btn-danger" onclick="return confirm('Anda Yakin akan Hapus Data Ini.....??')" href="<?php echo site_url('nilai/delete/'.$row->id_nilai); ?>">
										<i class="fa fa-trash-o"></i>
									</a>
								</td>
							</tr>
							<?php $no++; }?>
						</tbody>
					</table>
				</div>

			</div>
		</div>
		<!--End Advanced Tables -->
	</div>
</div>
