<script type="text/javascript">
	$(document).ready(function () {

		var site = "<?php echo site_url();?>";
		$(function(){
			$('.form-control').autocomplete({
				// serviceUrl berisi URL ke controller/fungsi yang menangani request kita
				serviceUrl: site+'/nilai/search',
				// fungsi ini akan dijalankan ketika user memilih salah satu hasil request
				onSelect: function (suggestion) {
					$('#nama').val(''+suggestion.nama);
					$('#id_kar').val(''+suggestion.id_kar);

				}
			});
		});

		$(function(){
			$('#save').click(function(){

			});
		});

		$(function() {
			$('.rating').barrating({
				theme: 'fontawesome-stars',
				onSelect: function(value, text, event) {
					// alert($(this).attr('id'));

					// Get element id by data-id attribute
					var el = this;
					var el_id = el.$elem.data('id');
					var kriteria = el.$elem.data('id-kriteria');

					// rating was selected by a user
					if (typeof(event) !== 'undefined') {
						// AJAX Request
						$.ajax({
							url: "<?php echo site_url('nilai/tambah') ?>",
							type: 'POST',
							data: {
								id_kriteria: kriteria,
								nilai: value
							},
							dataType: 'JSON',
							success: function(data){
								alert(data);
								// loadData();

							}
						});
					}
				}
			});
		});

});

</script>
	<div class="panel panel-default">
		  <div class="panel-body">
			<div class="row">
				<div class="col-lg-12">
					<!-- Advanced Tables -->
					<div class="col-md-8 col-sm-8">
						<form method="post" action="<?php echo site_url()?>nilai/add" enctype="multipart/form-data" >
						<div class="form-group">
							<label>Nama Bagian</label>
							<select name="bag" class="form-control" data-validation="required">
								<option value="">-- Pilih Bagian --</option>
								<?php $jenis = $this->db->get('bagian');
								foreach ($jenis->result()as $row){
									?>
									<option class="form-control" value="<?php echo $row->id_bagian ?>"><?php echo $row->nm_bagian; ?></option>
								<?php } ?>
							</select>
						</div>
						<div class="form-group">
							<label>Nama Karyawan</label>
							<input type="text" class="form-control" id="nama" name="nama" placeholder="Input Nama Karyawan" data-validation="required">
							<input type="hidden" id="id_kar" name="id_kar">
						</div>
						<div class="form-group">
							<label>Periode</label>
							<div class="input-group date">
								<div class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</div>
								<input type="text" class="form-control" name="per" id="per" data-validation="required">
							</div>
						</div>
						<div class="form-group">
							<label>Data Kriteria</label>
							<table class="table table-striped table-bordered table-hover" >
								<thead>
								<tr>
									<th>No </th>
									<th>pertanyaan</th>
									<th>Pilih Nilai Rating</th>
								</tr>
								</thead>
								<tbody>

								<?php $no=1; foreach ($kriteria as $row) {
								$postid = $row->id_kriteria;
								$averageRating = $nilai;
								if($averageRating <= "") {
									$averageRating = "Belum Ada Rating Nilai.";
								}
								 ?>
									<tr>

										<td><?php echo $no; ?></td>
										<td><input type="hidden" name="kriteria" id="kriteria" value="<?php echo $row->id_kriteria; ?>"><?php echo $row->nm_kriteria; ?></td>
										<td><div class="post-action">
												<!-- Rating -->
												<select class='rating' name="nilai[]" id='rating_<?php echo $postid; ?>' data-id-kriteria="<?php echo $row->id_kriteria;?>">
													<?php
													foreach ($nilai as $v) {
														if ($v->id_kriteria == $row->id_kriteria)
														{
															$nilai_rating = $v->nilai;
														}
													}
													?>
													<option value="20" <?php echo (isset($nilai_rating) && $nilai_rating == 20) ? 'selected=""' : ''?>>1</option>
													<option value="40" <?php echo (isset($nilai_rating) && $nilai_rating == 40) ? 'selected=""' : ''?>>2</option>
													<option value="60" <?php echo (isset($nilai_rating) && $nilai_rating == 60) ? 'selected=""' : ''?>>3</option>
													<option value="80" <?php echo (isset($nilai_rating) && $nilai_rating == 80) ? 'selected=""' : ''?>>4</option>
													<option value="100" <?php echo (isset($nilai_rating) && $nilai_rating == 100) ? 'selected=""' : ''?>>5</option>
												</select>
												<div style='clear: both;'></div>
										</td>
									</tr>
								<?php $no++; } ?>
								</tbody>
							</table>
						</div>
						<br>
						<button class="btn btn-primary" id="save">Simpan</button>
						<a href="<?php echo site_url() ?>nilai/view" class="btn btn-danger">Kembali</a>
					</form>
				</div>
			</div>
		</div>
	  </div>
	</div>
	<script>
		var myLanguage = {
			errorTitle : 'Tidak dapat dilanjutkan!',
			requiredFields : 'inputan ini harus diisi',
			badTime : 'Harus format waktu',
			badEmail : 'Harus format email',
			badTelephone : 'Harus format telepon',
			badSecurityAnswer : 'Pertanyaan keamanan salah',
			badDate : 'Kesalahan menulis tanggal',
			lengthBadStart : 'Harus input karakter antara ',
			lengthBadEnd : ' Karakter',
			lengthTooLongStart : 'Panjang karakter harus Kurang dari ',
			lengthTooShortStart : 'Panjang karakter harus Minimal ',
			notConfirmed : 'Konfirmasi terlebih dahulu',
			badDomain : 'Harus format nama domain',
			badUrl : 'Harus format URL',
			badCustomVal : 'You gave an incorrect answer',
			badInt : 'Harus karakter angka',
			badSecurityNumber : 'Your social security number was incorrect',
			badUKVatAnswer : 'Incorrect UK VAT Number',
			badStrength : 'The password isn\'t strong enough',
			badNumberOfSelectedOptionsStart : 'You have to choose at least ',
			badNumberOfSelectedOptionsEnd : ' answers',
			badAlphaNumeric : 'The answer you gave must contain only alphanumeric characters ',
			badAlphaNumericExtra: ' and ',
			wrongFileSize : 'The file you are trying to upload is too large',
			wrongFileType : 'The file you are trying to upload is of wrong type',
			groupCheckedRangeStart : 'Please choose between ',
			groupCheckedTooFewStart : 'Please choose at least ',
			groupCheckedTooManyStart : 'Please choose a maximum of ',
			groupCheckedEnd : ' item(s)'
		};
		$.validate({
			language : myLanguage
		});
	</script>
