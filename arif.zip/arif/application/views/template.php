<!DOCTYPE html>
<html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Penilaian Kinerja Karyawan</title>
<head>
	<?php echo $headernya; ?>

	<?php echo $jsnya; ?>
	<script type="text/javascript">
		setInterval(function(){
			$("#load_row").load('<?=base_url()?>notif/load_row')
		}, 5000); //menggunakan setinterval jumlah notifikasi akan selalu update setiap 2 detik diambil dari controller notifikasi fungsi load_row

		setInterval(function(){
			$("#load_data").load('<?=base_url()?>notif/load_data')
		}, 5000); //yang ini untuk sela

		function myFunction() {
			$.ajax({
				url: "<?=site_url()?>notif/view",
				type: "POST",
				processData:false,
				success: function(data){
					$("#load_row").remove();
					$("#notif-latest").show();$("#notif-latest").html(data);
				},
				error: function(){}
			});
		}

		$(document).ready(function() {
			$('body').click(function(e){
				if ( e.target.id != 'notif-icon'){
					$("#notif-latest").hide();
				}
			});
		});
	</script>
</head>

<body>
<!--  wrapper -->
<div id="wrapper">
	<!-- navbar top -->
	<nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
		<!-- navbar-header -->
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" style="width: 350px;">
				<img src="<?php echo base_url(); ?>siminta/assets/img/arai.jpeg" />
			</a>
			<h3>Aplikasi Kinerja Karyawan</h3>
		</div>
		<!-- end navbar-header -->
		<!-- navbar-top-links -->
		<ul class="nav navbar-top-links navbar-right">
			<!-- main dropdown -->

			<li class="dropdown">
				<a class="dropdown-toggle" id="notif-icon" data-toggle="dropdown" onclick="myFunction()" href="#">

					<span class="top-label label label-warning" id="load_row" ><?php if( ! empty($jnotif)) $sess_bag = $this->session->userdata('level');
					if($sess_bag == 'supervisor'){ echo $jnotif;} ?></span> <i class="fa fa-bell fa-2x"></i>
				</a>

				<!-- dropdown alerts-->
				<ul class="dropdown-menu dropdown-alerts" id="load_data">
					<? $no=0; foreach($getnotif as $rnotif){ $no++;
						if($no % 2==0){$strip='strip1';}  //agar pesan yang tampil striped beda warna
						else{$strip='strip2';}
						?>
						<?php if(isset($success)) { ?> <div class="success"><?php echo $success;?></div> <?php } ?>
						<li><a href="#" >
							<div>
								<i class="fa fa-envelope fa-fw"></i>
								<?=$rnotif->id_bagian?>
								<span class="pull-right text-muted small"><?=$rnotif->nm_bagian ?></span>
							</div>
							</a>
						</li>
					<? }?>
					<li class="divider"></li>
				</ul>
				<!-- end dropdown-alerts -->
			</li>

			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">
					<i class="fa fa-user fa-3x"></i>
				</a>
				<!-- dropdown user-->
				<ul class="dropdown-menu dropdown-user">
					<li><a href="#"><i class="fa fa-user fa-fw"></i>User Profile</a>
					</li>
					<li class="divider"></li>
					<li><a href="<?php echo base_url() ?>Auth/logout"><i class="fa fa-sign-out fa-fw"></i>Logout</a>
					</li>
				</ul>
				<!-- end dropdown-user -->
			</li>
			<!-- end main dropdown -->
		</ul>


		<!-- end navbar-top-links -->
	</nav>
	<!-- end navbar top -->

	<!-- navbar side -->
	<?php echo $sidebarnya; ?>
	<!-- end navbar side -->
	<!--  page-wrapper -->
	<div id="page-wrapper">


		<div class="row">
			<!--  page header -->
			<div class="col-lg-12">
				<h1 class="page-header"><?php echo $judul; ?></h1>
			</div>
			<!-- end  page header -->
		</div>
	<?php echo $contentnya; ?>
	</div>
	<!-- end page-wrapper -->

</div>
<!-- end wrapper -->

<!-- Core Scripts - Include with every page -->

<script>
	$(document).ready(function () {
		$('#dataTables-example').dataTable();

		//datepicker
		$('.datepicker').datepicker({
			autoclose: true,
			format: "yyyy-mm-dd",
			todayHighlight: true,
			orientation: "top auto",
			todayBtn: true,
			todayHighlight: true,
		});

		$(function () {
			//Date picker
			$('#tgl').datepicker({
				autoclose: true,
				format: "yyyy-mm-dd",
				todayHighlight: true,
			});
		});
		$(function () {
			//Date picker
			$('#per').datepicker({
				autoclose: true,
				format: "yyyy-mm",
				todayHighlight: true,
			});
		});

	});
</script>
<script>
	var myLanguage = {
		errorTitle : 'Tidak dapat dilanjutkan!',
		requiredFields : 'inputan ini harus diisi',
		badTime : 'Harus format waktu',
		badEmail : 'Harus format email',
		badTelephone : 'Harus format telepon',
		badSecurityAnswer : 'Pertanyaan keamanan salah',
		badDate : 'Kesalahan menulis tanggal',
		lengthBadStart : 'Harus input karakter antara ',
		lengthBadEnd : ' Karakter',
		lengthTooLongStart : 'Panjang karakter harus Kurang dari ',
		lengthTooShortStart : 'Panjang karakter harus Minimal ',
		notConfirmed : 'Konfirmasi terlebih dahulu',
		badDomain : 'Harus format nama domain',
		badUrl : 'Harus format URL',
		badCustomVal : 'You gave an incorrect answer',
		badInt : 'Harus karakter angka',
		badSecurityNumber : 'Your social security number was incorrect',
		badUKVatAnswer : 'Incorrect UK VAT Number',
		badStrength : 'The password isn\'t strong enough',
		badNumberOfSelectedOptionsStart : 'You have to choose at least ',
		badNumberOfSelectedOptionsEnd : ' answers',
		badAlphaNumeric : 'The answer you gave must contain only alphanumeric characters ',
		badAlphaNumericExtra: ' and ',
		wrongFileSize : 'The file you are trying to upload is too large',
		wrongFileType : 'The file you are trying to upload is of wrong type',
		groupCheckedRangeStart : 'Please choose between ',
		groupCheckedTooFewStart : 'Please choose at least ',
		groupCheckedTooManyStart : 'Please choose a maximum of ',
		groupCheckedEnd : ' item(s)'
	};
	$.validate({
		language : myLanguage
	});
</script>
</body>

</html>
